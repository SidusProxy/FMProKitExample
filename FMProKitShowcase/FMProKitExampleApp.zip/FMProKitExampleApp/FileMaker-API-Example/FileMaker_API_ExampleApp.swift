//
//  FileMaker_API_ExampleApp.swift
//  FileMaker-API-Example
//
//  Created by Francesco De Marco on 19/04/23.
//

import SwiftUI
import FMProKit


@main
struct FMProKitApp: App {
    
    static let apiCaller = FMODataAPI(server: "napoli.fm-testing.com", database: "Shop", username: "Admin", password: "admin")

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
